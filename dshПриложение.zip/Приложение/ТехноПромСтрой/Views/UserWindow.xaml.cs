﻿using System.Windows;

namespace ТехноПромСтрой
{
    public partial class UserWindow : Window
    {
        public UserWindow(string fullName)
        {
            InitializeComponent();
            txtWelcome.Text = $"👤 Здравствуйте, {fullName}";
        }
    }
}