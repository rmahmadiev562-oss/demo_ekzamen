﻿using System;
using System.Windows;

namespace molokozov
{
    public partial class MainWindow : Window
    {
        private DatabaseHelper db = new DatabaseHelper();
        private int captchaErrors = 0;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            string login = txtLogin.Text.Trim();
            string pass = txtPass.Password;
            // Проверка заполнены ли поля
            if (string.IsNullOrWhiteSpace(login))
            {
                MessageBox.Show("Поле Логин обязательно для заполнения", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                txtLogin.Focus();
                return;
            }

            if (string.IsNullOrEmpty(pass))
            {
                MessageBox.Show("Поле Пароль обязательно для заполнения", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                txtPass.Focus();
                return;
            }
            //Проверка капчи
            if (!captcha.IsValid)
            {
                captchaErrors++;
                if (captchaErrors >= 3)
                {
                    MessageBox.Show("Пазл собран неверно 3 раза. Перезапустите программу.", "Капча", MessageBoxButton.OK, MessageBoxImage.Error);
                    btnLogin.IsEnabled = false;
                }
                else
                {
                    MessageBox.Show($"Пазл собран неверно. Осталось попыток: {3 - captchaErrors}", "Капча", MessageBoxButton.OK, MessageBoxImage.Warning);
                    captcha.Reset();
                }
                return;
            }

            captchaErrors = 0;

            try
            {
                var userData = db.GetUser(login);

                if (userData == null)
                {
                    MessageBox.Show("Вы ввели неверный логин или пароль. Пожалуйста проверьте ещё раз введенные данные", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    txtPass.Clear();
                    txtPass.Focus();
                    captcha.Reset();
                    return;
                }

                object[] data = (object[])userData;
                string dbPass = (string)data[2];
                string role = (string)data[4];
                bool isBlocked = (bool)data[5];
                int attempts = (int)data[6];
                string fullName = data[3] == DBNull.Value ? "" : (string)data[3];

                if (isBlocked)
                {
                    MessageBox.Show("Вы заблокированы. Обратитесь к администратору.", "Доступ запрещен", MessageBoxButton.OK, MessageBoxImage.Stop);
                    return;
                }

                if (pass != dbPass)
                {
                    attempts++;
                    if (attempts >= 3)
                    {
                        db.UpdateAttempts(login, attempts, true);
                        MessageBox.Show("Вы заблокированы. Обратитесь к администратору.", "Доступ запрещен", MessageBoxButton.OK, MessageBoxImage.Stop);
                    }
                    else
                    {
                        db.UpdateAttempts(login, attempts, false);
                        MessageBox.Show($"Неверный пароль. Осталось попыток: {3 - attempts}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                        txtPass.Clear();
                        txtPass.Focus();
                        captcha.Reset();
                    }
                    return;
                }

                db.ResetAttempts(login);
                MessageBox.Show("Вы успешно авторизовались", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);

                //Проверка роли - Admin или User
                //Проверь что в базе данных есть роль Admin, а не Администратор, например
                if (role == "Admin")
                {
                    AdminWindow adminWin = new AdminWindow(db);
                    adminWin.Show();
                }
                else
                {
                    UserWindow userWin = new UserWindow(fullName);
                    userWin.Show();
                }

                this.Close();
            }
            //Проверяем есть ли подключение к БД. Если нет - ошибка
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка подключения к базе данных: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}