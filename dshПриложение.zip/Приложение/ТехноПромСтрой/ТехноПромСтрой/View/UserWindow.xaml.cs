﻿using System.Windows;

namespace molokozov
{
    public partial class UserWindow : Window
    {
        public UserWindow(string fullName)
        {
            InitializeComponent();
            txtWelcome.Text = $"Здравствуйте, {fullName}";
        }
    }
}