﻿using System;
using System.Collections.ObjectModel;
using System.Windows;

namespace molokozov
{
    public partial class AdminWindow : Window
    {
        private DatabaseHelper db;
        private ObservableCollection<UserViewModel> users;

        public AdminWindow(DatabaseHelper database)
        {
            InitializeComponent();
            db = database;
            LoadData();
        }

        private void LoadData()
        {
            users = new ObservableCollection<UserViewModel>();
            var data = db.GetAllUsers();
            foreach (var item in data)
            {
                object[] arr = (object[])item;
                users.Add(new UserViewModel
                {
                    Id = (int)arr[0],
                    Login = (string)arr[1],
                    FullName = arr[2] == DBNull.Value ? "" : (string)arr[2],
                    Role = (string)arr[3],
                    IsBlocked = (bool)arr[4],
                    FailedAttempts = (int)arr[5]
                });
            }
            dgUsers.ItemsSource = users;
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            AddUserWindow addWin = new AddUserWindow(db);
            if (addWin.ShowDialog() == true)
                LoadData();
        }
        //Сохранение данных пользователя
        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            if (dgUsers.SelectedItem == null)
            {
                MessageBox.Show("Выберите пользователя", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            UserViewModel selected = (UserViewModel)dgUsers.SelectedItem;
            db.UpdateUser(selected.Id, selected.FullName, selected.Role, selected.IsBlocked);
            MessageBox.Show("Данные сохранены", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            LoadData();
        }

        //Удаление пользователя

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (dgUsers.SelectedItem == null)
            {
                MessageBox.Show("Выберите пользователя", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            UserViewModel selected = (UserViewModel)dgUsers.SelectedItem;

            if (MessageBox.Show($"Удалить пользователя {selected.Login}?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                db.DeleteUser(selected.Id);
                LoadData();
            }
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            LoadData();
        }
    }
    //Загрузка информации из БД
    public class UserViewModel
    {
        public int Id { get; set; }
        public string Login { get; set; }
        public string FullName { get; set; }
        public string Role { get; set; }
        public bool IsBlocked { get; set; }
        public int FailedAttempts { get; set; }
    }
}