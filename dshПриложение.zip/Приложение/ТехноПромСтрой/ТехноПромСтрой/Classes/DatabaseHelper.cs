﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace molokozov
{
    public class DatabaseHelper
    {
        // Строка подключения. Необходимо менять!
        string connStr = "Server=DESKTOP-FSVJ82Q\\SQLEXPRESS;Database=MolKomb;Integrated Security=True;";

        //Здесь мы получаем список пользователей
        public object GetUser(string login)
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT Id, Login, PasswordHash, FullName, Role, IsBlocked, FailedAttempts FROM Users WHERE Login=@l", conn);
                cmd.Parameters.AddWithValue("@l", login);
                SqlDataReader r = cmd.ExecuteReader();
                if (r.Read())
                {
                    return new object[] { r[0], r[1], r[2], r[3], r[4], r[5], r[6] };
                }
                return null;
            }
        }

        // Обновляем данные, проверяем блокировки
        public void UpdateAttempts(string login, int attempts, bool blocked)
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("UPDATE Users SET FailedAttempts=@a, IsBlocked=@b WHERE Login=@l", conn);
                cmd.Parameters.AddWithValue("@a", attempts);
                cmd.Parameters.AddWithValue("@b", blocked);
                cmd.Parameters.AddWithValue("@l", login);
                cmd.ExecuteNonQuery();
            }
        }
        //Сброс блокировок
        public void ResetAttempts(string login)
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("UPDATE Users SET FailedAttempts=0, IsBlocked=0 WHERE Login=@l", conn);
                cmd.Parameters.AddWithValue("@l", login);
                cmd.ExecuteNonQuery();
            }
        }
        //Получаем список пользователей
        public List<object[]> GetAllUsers()
        {
            List<object[]> list = new List<object[]>();
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT Id, Login, FullName, Role, IsBlocked, FailedAttempts FROM Users", conn);
                SqlDataReader r = cmd.ExecuteReader();
                while (r.Read())
                {
                    list.Add(new object[] { r[0], r[1], r[2], r[3], r[4], r[5] });
                }
            }
            return list;
        }

        //Добавляем пользователей
        public bool AddUser(string login, string pass, string name, string role)
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                SqlCommand check = new SqlCommand("SELECT COUNT(*) FROM Users WHERE Login=@l", conn);
                check.Parameters.AddWithValue("@l", login);
                if ((int)check.ExecuteScalar() > 0) return false;

                SqlCommand cmd = new SqlCommand("INSERT INTO Users (Login, PasswordHash, FullName, Role, IsBlocked, FailedAttempts) VALUES (@l,@p,@n,@r,0,0)", conn);
                cmd.Parameters.AddWithValue("@l", login);
                cmd.Parameters.AddWithValue("@p", pass);
                cmd.Parameters.AddWithValue("@n", name);
                cmd.Parameters.AddWithValue("@r", role);
                cmd.ExecuteNonQuery();
                return true;
            }
        }
        // Для обновления списка пользователей
        public void UpdateUser(int id, string name, string role, bool blocked, string newPass = null)
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                if (!string.IsNullOrEmpty(newPass))
                {
                    SqlCommand cmd = new SqlCommand("UPDATE Users SET FullName=@n, Role=@r, IsBlocked=@b, PasswordHash=@p WHERE Id=@id", conn);
                    cmd.Parameters.AddWithValue("@p", newPass);
                    cmd.Parameters.AddWithValue("@n", name);
                    cmd.Parameters.AddWithValue("@r", role);
                    cmd.Parameters.AddWithValue("@b", blocked);
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.ExecuteNonQuery();
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("UPDATE Users SET FullName=@n, Role=@r, IsBlocked=@b WHERE Id=@id", conn);
                    cmd.Parameters.AddWithValue("@n", name);
                    cmd.Parameters.AddWithValue("@r", role);
                    cmd.Parameters.AddWithValue("@b", blocked);
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.ExecuteNonQuery();
                }
            }
        }
        //Для удаления
        public void DeleteUser(int id)
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("DELETE FROM Users WHERE Id=@id", conn);
                cmd.Parameters.AddWithValue("@id", id);
                cmd.ExecuteNonQuery();
            }
        }
    }
}