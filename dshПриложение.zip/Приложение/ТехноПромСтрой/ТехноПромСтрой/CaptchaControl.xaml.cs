﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace molokozov
{
    public partial class CaptchaControl : UserControl
    {
        private List<Image> pieces = new List<Image>();
        private List<int> correctOrder = new List<int>();
        private List<int> currentOrder = new List<int>();
        private Image draggedItem = null;
        private Random rand = new Random();

        public bool IsValid { get; private set; } = false;

        public CaptchaControl()
        {
            InitializeComponent();
            Loaded += CaptchaControl_Loaded;
        }

        private void CaptchaControl_Loaded(object sender, RoutedEventArgs e)
        {
            CreatePuzzle();
        }

        private void CreatePuzzle()
        {
            PuzzleGrid.Children.Clear();
            pieces.Clear();
            correctOrder.Clear();
            currentOrder.Clear();

            string[] imageFiles = new string[]
  {
    "piece1.jpg",
    "piece2.jpg",
    "piece3.jpg",
    "piece4.jpg"
  };

            for (int i = 0; i < 4; i++)
            {
                BitmapImage src = new BitmapImage();
                src.BeginInit();
                src.UriSource = new Uri(imageFiles[i], UriKind.Relative);
                src.CacheOption = BitmapCacheOption.OnLoad;
                src.EndInit();

                Image img = new Image();
                img.Source = src;
                img.Width = 120;
                img.Height = 120;
                img.Tag = i;
                img.Margin = new Thickness(2);
                img.Cursor = Cursors.Hand;

                img.MouseLeftButtonDown += Img_MouseLeftButtonDown;
                img.MouseMove += Img_MouseMove;
                img.Drop += Img_Drop;
                img.AllowDrop = true;

                pieces.Add(img);
                correctOrder.Add(i);
                currentOrder.Add(i);
            }

            Shuffle();
            DrawPuzzle();
        }

        private void Img_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            draggedItem = sender as Image;
            DragDrop.DoDragDrop(draggedItem, draggedItem.Tag, DragDropEffects.Move);
        }

        private void Img_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed && draggedItem != null)
            {
                DragDrop.DoDragDrop(draggedItem, draggedItem.Tag, DragDropEffects.Move);
            }
        }

        private void Img_Drop(object sender, DragEventArgs e)
        {
            Image target = sender as Image;
            int sourceIndex = (int)e.Data.GetData(typeof(int));
            int targetIndex = (int)target.Tag;

            if (sourceIndex != targetIndex)
            {
                int sourcePos = currentOrder.IndexOf(sourceIndex);
                int targetPos = currentOrder.IndexOf(targetIndex);

                int temp = currentOrder[sourcePos];
                currentOrder[sourcePos] = currentOrder[targetPos];
                currentOrder[targetPos] = temp;

                DrawPuzzle();
            }
            draggedItem = null;
        }

        private void Shuffle()
        {
            for (int i = 0; i < 30; i++)
            {
                int a = rand.Next(4);
                int b = rand.Next(4);
                int temp = currentOrder[a];
                currentOrder[a] = currentOrder[b];
                currentOrder[b] = temp;
            }
        }

        private void DrawPuzzle()
        {
            PuzzleGrid.Children.Clear();
            foreach (int idx in currentOrder)
            {
                PuzzleGrid.Children.Add(pieces[idx]);
            }
        }

        private void ShuffleBtn_Click(object sender, RoutedEventArgs e)
        {
            Shuffle();
            DrawPuzzle();
            IsValid = false;
        }

        private void CheckBtn_Click(object sender, RoutedEventArgs e)
        {
            IsValid = true;
            for (int i = 0; i < 4; i++)
            {
                if (currentOrder[i] != correctOrder[i])
                {
                    IsValid = false;
                    break;
                }
            }

            if (IsValid)
                MessageBox.Show("Пазл собран правильно!", "Капча", MessageBoxButton.OK, MessageBoxImage.Information);
            else
                MessageBox.Show("Пазл собран неверно!", "Капча", MessageBoxButton.OK, MessageBoxImage.Warning);
        }

        public void Reset()
        {
            Shuffle();
            DrawPuzzle();
            IsValid = false;
        }
    }
}